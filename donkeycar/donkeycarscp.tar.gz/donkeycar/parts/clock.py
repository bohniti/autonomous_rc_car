import datetime


class Timestamp():

    def run(self,):
        return str(datetime.datetime.utcnow())
